<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-md-8 ml-auto mr-auto">

                <div class="card">
                    <div class="card-header">
                        <h2 class="text-xl font-semibold leading-tight text-gray-800">
                            <?php echo e($thread->subject); ?>

                        </h2>

                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <?php $__currentLoopData = $thread->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="px-4 py-2 leading-relaxed border rounded-lg sm:px-6 sm:py-4">
                                    <strong><?php echo e($message->user->name); ?></strong>
                                    <span class="text-xs text-gray-400"><?php echo e($message->created_at->diffForHumans()); ?>

                                    </span>
                                    <p class="text-sm">
                                        <?php echo e($message->body); ?>

                                    </p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>


                        </div>

                        <div class="row mt-4">
                            <div class="col-md-12 col-sm-12">

                                <form class="form" method="POST" action="<?php echo e(route('messages.update', $thread)); ?>" enctype="multipart/form-data"
                                >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                    <div class="card ">


                                        <div class="card-body ">
                                            <h4 class="title">Reply Message</h4>

                                            <div class="row">


                                                <div class="col-md-12 ">
                                                    <div class="form-group">
                                                        Message
                                                        <textarea rows="2" cols="80" class="form-control" placeholder="Add Reply..." name="message" ></textarea>

                                                    </div>
                                                </div>
                                            </div>


                                            <button type="submit" class="btn btn-info btn-fill pull-right">Send</button>
                                            <div class="clearfix"></div>
                                        </div>
                                    </div>
                                </form>

                            </div>

                        </div>





                    </div>
                </div>
            </div>






    <!-- end col-md-8 -->
</div>

<!-- Modal -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\starn\rental\resources\views/messenger/show.blade.php ENDPATH**/ ?>