<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="container-fluid">


            <div class="row">
                <div class="col-md-12">
                    <div class="card ">
                        <div class="card-header ">
                            <h4 class="card-title">PAYMENTS OVER TIME </h4>
                            <p class="card-category">Line Chart</p>
                        </div>
                        <div class="card-body ">
                            <?php echo $chart1->renderHtml(); ?>

                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Charting library -->
<script src="https://unpkg.com/chart.js@^2.9.3/dist/Chart.min.js"></script>
<!-- Chartisan -->
<script src="https://unpkg.com/@chartisan/chartjs@^2.1.0/dist/chartisan_chartjs.umd.js"></script>
<!-- Your application script -->

<?php echo $chart1->renderChartJsLibrary(); ?>

<?php echo $chart1->renderJs(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\starn\rental\resources\views/reports/payments.blade.php ENDPATH**/ ?>